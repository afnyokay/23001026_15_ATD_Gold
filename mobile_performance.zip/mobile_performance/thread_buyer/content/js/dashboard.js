/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.48346153846153844, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.17, 500, 1500, "put buyer produk by id"], "isController": false}, {"data": [0.0325, 500, 1500, "POST buyer"], "isController": false}, {"data": [1.0, 500, 1500, "Get buyer order id-0"], "isController": false}, {"data": [0.61, 500, 1500, "Get buyer order id-1"], "isController": false}, {"data": [0.5975, 500, 1500, "Get buyer order id"], "isController": false}, {"data": [0.4125, 500, 1500, "login"], "isController": false}, {"data": [0.1825, 500, 1500, "put buyer produk by id-1"], "isController": false}, {"data": [1.0, 500, 1500, "put buyer produk by id-0"], "isController": false}, {"data": [1.0, 500, 1500, "POST buyer-0"], "isController": false}, {"data": [0.035, 500, 1500, "POST buyer-1"], "isController": false}, {"data": [0.115, 500, 1500, "Get buyer order"], "isController": false}, {"data": [0.13, 500, 1500, "Get buyer order-1"], "isController": false}, {"data": [1.0, 500, 1500, "Get buyer order-0"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 2600, 0, 0.0, 1080.1211538461566, 14, 3833, 1142.5, 2144.8, 2577.499999999998, 3207.9199999999983, 33.3628466207286, 17.683912691996767, 33.58855710500315], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["put buyer produk by id", 200, 0, 0.0, 1681.479999999999, 1020, 2994, 1600.0, 2291.5000000000005, 2646.1, 2989.5300000000007, 2.817377584943934, 1.8571580760128472, 2.701078219206063], "isController": false}, {"data": ["POST buyer", 200, 0, 0.0, 2259.999999999999, 1200, 3833, 2137.5, 3106.5, 3437.2999999999993, 3688.2200000000007, 2.737101409607226, 1.7828580470781443, 11.08151857807582], "isController": false}, {"data": ["Get buyer order id-0", 200, 0, 0.0, 25.234999999999996, 14, 310, 24.0, 32.0, 34.0, 52.87000000000012, 2.8773666340565116, 1.1492606966104622, 0.9694252819819302], "isController": false}, {"data": ["Get buyer order id-1", 200, 0, 0.0, 729.7800000000002, 190, 1580, 740.5, 1163.3000000000002, 1271.6999999999998, 1441.97, 2.8339048374755578, 2.404944632584238, 0.9547823915322924], "isController": false}, {"data": ["Get buyer order id", 200, 0, 0.0, 755.1249999999999, 210, 1610, 762.5, 1186.4000000000003, 1300.85, 1470.8200000000002, 2.8327006968443715, 3.5353432525069404, 1.9087533992408363], "isController": false}, {"data": ["login", 200, 0, 0.0, 1255.5549999999994, 530, 2814, 1228.5, 1646.6, 1996.2499999999993, 2553.82, 2.7623927846300464, 1.3002669162028149, 1.1303150163671773], "isController": false}, {"data": ["put buyer produk by id-1", 200, 0, 0.0, 1656.945, 990, 2973, 1578.5, 2262.4, 2615.2, 2960.5300000000007, 2.8185290097098323, 0.7376618892599952, 0.9440971194633521], "isController": false}, {"data": ["put buyer produk by id-0", 200, 0, 0.0, 24.46500000000001, 14, 42, 27.0, 30.900000000000006, 31.94999999999999, 36.960000000000036, 2.8709232889297196, 1.1410798619085898, 1.7907664378301562], "isController": false}, {"data": ["POST buyer-0", 200, 0, 0.0, 32.204999999999984, 16, 67, 30.0, 48.0, 49.94999999999999, 62.960000000000036, 2.7816411682892905, 1.0892950278164115, 10.346401251738525], "isController": false}, {"data": ["POST buyer-1", 200, 0, 0.0, 2227.7050000000013, 1170, 3802, 2106.0, 3077.4, 3416.099999999999, 3639.3200000000006, 2.7385630759540467, 0.7113845490271254, 0.9012653873012829], "isController": false}, {"data": ["Get buyer order", 200, 0, 0.0, 1696.5750000000012, 962, 2211, 1734.5, 2118.0, 2154.75, 2181.9700000000003, 2.8062298302230952, 1.8278860319910202, 1.847069243721061], "isController": false}, {"data": ["Get buyer order-1", 200, 0, 0.0, 1671.3149999999996, 930, 2181, 1709.5, 2097.0, 2129.95, 2165.88, 2.807411566535654, 0.7292690202133634, 0.9239235331274566], "isController": false}, {"data": ["Get buyer order-0", 200, 0, 0.0, 25.189999999999987, 14, 74, 27.5, 31.0, 33.0, 48.99000000000001, 2.8786919223904657, 1.1273002547642352, 0.947382009614831], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 2600, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
