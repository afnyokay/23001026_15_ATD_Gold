/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.42846153846153845, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.16, 500, 1500, "delete produk-1"], "isController": false}, {"data": [1.0, 500, 1500, "delete produk-0"], "isController": false}, {"data": [0.095, 500, 1500, "POST seller"], "isController": false}, {"data": [0.42, 500, 1500, "login"], "isController": false}, {"data": [0.14, 500, 1500, "Get produk"], "isController": false}, {"data": [0.155, 500, 1500, "delete produk"], "isController": false}, {"data": [1.0, 500, 1500, "Get seller produk id-0"], "isController": false}, {"data": [0.18, 500, 1500, "Get seller produk id-1"], "isController": false}, {"data": [1.0, 500, 1500, "POST seller-0"], "isController": false}, {"data": [0.1, 500, 1500, "POST seller-1"], "isController": false}, {"data": [1.0, 500, 1500, "Get produk-0"], "isController": false}, {"data": [0.175, 500, 1500, "Get seller produk id"], "isController": false}, {"data": [0.145, 500, 1500, "Get produk-1"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 2600, 0, 0.0, 1293.7846153846158, 14, 3950, 1363.5, 2618.0, 2918.499999999998, 3467.7099999999937, 28.61387773069939, 28.00987385131789, 30.40998321686018], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["delete produk-1", 200, 0, 0.0, 1865.4399999999998, 81, 3899, 2046.0, 2617.9, 2766.5499999999993, 3741.3800000000006, 2.426301103967002, 1.6728208783209995, 0.8198243964576003], "isController": false}, {"data": ["delete produk-0", 200, 0, 0.0, 25.085000000000008, 15, 42, 29.0, 31.0, 33.94999999999999, 39.0, 2.4278326737721234, 0.9720814416470417, 1.1250064489305398], "isController": false}, {"data": ["POST seller", 200, 0, 0.0, 2220.8449999999984, 1034, 3950, 2127.5, 3117.0, 3438.6, 3888.51, 2.244190352225676, 4.4182497559442995, 10.238680163601476], "isController": false}, {"data": ["login", 200, 0, 0.0, 1163.4449999999995, 350, 2888, 1092.5, 1864.4, 2196.0499999999997, 2844.9100000000008, 2.263595721804086, 1.0632710372927394, 0.9262173900741327], "isController": false}, {"data": ["Get produk", 200, 0, 0.0, 1796.6500000000005, 890, 3340, 1850.0, 2370.9, 2438.2999999999997, 2786.2800000000007, 2.3210472565221427, 4.569561786277968, 1.5413204437842354], "isController": false}, {"data": ["delete produk", 200, 0, 0.0, 1890.595000000001, 101, 3916, 2067.5, 2639.7, 2796.1999999999994, 3761.4900000000007, 2.425447798299761, 2.643359123928255, 1.943437420414994], "isController": false}, {"data": ["Get seller produk id-0", 200, 0, 0.0, 25.915000000000003, 14, 42, 29.0, 33.0, 34.0, 36.0, 2.376792993214256, 0.9516456320486767, 0.8030960699727857], "isController": false}, {"data": ["Get seller produk id-1", 200, 0, 0.0, 1893.9799999999977, 270, 3351, 1866.5, 2924.6, 3155.599999999999, 3330.84, 2.369949046095509, 1.6594272129399217, 0.8007835644033653], "isController": false}, {"data": ["POST seller-0", 200, 0, 0.0, 32.19, 16, 95, 30.0, 48.0, 50.0, 56.940000000000055, 2.2743037787557285, 0.8972839127122211, 9.620926864076235], "isController": false}, {"data": ["POST seller-1", 200, 0, 0.0, 2188.5699999999983, 1012, 3912, 2094.0, 3083.3, 3411.85, 3838.67, 2.245046865353314, 3.534194870067913, 0.7454257170118427], "isController": false}, {"data": ["Get produk-0", 200, 0, 0.0, 25.55, 14, 45, 28.0, 31.0, 34.0, 40.98000000000002, 2.3447483498833486, 0.9250764974149149, 0.7785297255472057], "isController": false}, {"data": ["Get seller produk id", 200, 0, 0.0, 1919.9599999999994, 300, 3380, 1892.0, 2955.4, 3185.249999999999, 3359.8500000000004, 2.369162974721031, 2.6074674536236344, 1.6010359165106967], "isController": false}, {"data": ["Get produk-1", 200, 0, 0.0, 1770.975, 871, 3310, 1828.0, 2341.0, 2403.8, 2769.1600000000008, 2.3218017181332713, 3.655023798467611, 0.7709107267239378], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 2600, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
