/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.4559615384615385, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.16, 500, 1500, "delete produk-1"], "isController": false}, {"data": [1.0, 500, 1500, "delete produk-0"], "isController": false}, {"data": [0.095, 500, 1500, "POST seller"], "isController": false}, {"data": [0.41625, 500, 1500, "login"], "isController": false}, {"data": [0.14, 500, 1500, "Get produk"], "isController": false}, {"data": [1.0, 500, 1500, "POST seller-0"], "isController": false}, {"data": [0.1, 500, 1500, "POST seller-1"], "isController": false}, {"data": [0.115, 500, 1500, "Get buyer order"], "isController": false}, {"data": [0.17, 500, 1500, "put buyer produk by id"], "isController": false}, {"data": [0.0325, 500, 1500, "POST buyer"], "isController": false}, {"data": [1.0, 500, 1500, "Get buyer order id-0"], "isController": false}, {"data": [0.61, 500, 1500, "Get buyer order id-1"], "isController": false}, {"data": [0.5975, 500, 1500, "Get buyer order id"], "isController": false}, {"data": [0.1825, 500, 1500, "put buyer produk by id-1"], "isController": false}, {"data": [1.0, 500, 1500, "put buyer produk by id-0"], "isController": false}, {"data": [0.155, 500, 1500, "delete produk"], "isController": false}, {"data": [1.0, 500, 1500, "POST buyer-0"], "isController": false}, {"data": [1.0, 500, 1500, "Get seller produk id-0"], "isController": false}, {"data": [0.035, 500, 1500, "POST buyer-1"], "isController": false}, {"data": [0.18, 500, 1500, "Get seller produk id-1"], "isController": false}, {"data": [1.0, 500, 1500, "Get produk-0"], "isController": false}, {"data": [0.175, 500, 1500, "Get seller produk id"], "isController": false}, {"data": [0.145, 500, 1500, "Get produk-1"], "isController": false}, {"data": [0.13, 500, 1500, "Get buyer order-1"], "isController": false}, {"data": [1.0, 500, 1500, "Get buyer order-0"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 5200, 0, 0.0, 1186.9528846153853, 14, 3950, 1244.5, 2439.9000000000005, 2770.0, 3401.8399999999965, 57.22775546139878, 43.17660471578716, 59.21744311616134], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["delete produk-1", 200, 0, 0.0, 1865.4399999999998, 81, 3899, 2046.0, 2617.9, 2766.5499999999993, 3741.3800000000006, 2.426301103967002, 1.6728208783209995, 0.8198243964576003], "isController": false}, {"data": ["delete produk-0", 200, 0, 0.0, 25.085000000000008, 15, 42, 29.0, 31.0, 33.94999999999999, 39.0, 2.4278326737721234, 0.9720814416470417, 1.1250064489305398], "isController": false}, {"data": ["POST seller", 200, 0, 0.0, 2220.844999999998, 1034, 3950, 2127.5, 3117.0, 3438.6, 3888.51, 2.244190352225676, 4.4182497559442995, 10.238680163601476], "isController": false}, {"data": ["login", 400, 0, 0.0, 1209.4999999999993, 350, 2888, 1178.0, 1745.8000000000006, 2077.1499999999996, 2735.170000000002, 4.527191443608172, 2.128752617282553, 1.8524347801482655], "isController": false}, {"data": ["Get produk", 200, 0, 0.0, 1796.6500000000003, 890, 3340, 1850.0, 2370.9, 2438.2999999999997, 2786.2800000000007, 2.3210472565221427, 4.569561786277968, 1.5413204437842354], "isController": false}, {"data": ["POST seller-0", 200, 0, 0.0, 32.19, 16, 95, 30.0, 48.0, 50.0, 56.940000000000055, 2.2743037787557285, 0.8972839127122211, 9.620926864076235], "isController": false}, {"data": ["POST seller-1", 200, 0, 0.0, 2188.5699999999983, 1012, 3912, 2094.0, 3083.3, 3411.85, 3838.67, 2.245046865353314, 3.534194870067913, 0.7454257170118427], "isController": false}, {"data": ["Get buyer order", 200, 0, 0.0, 1696.5750000000012, 962, 2211, 1734.5, 2118.0, 2154.75, 2181.9700000000003, 2.8062298302230952, 1.8278860319910202, 1.847069243721061], "isController": false}, {"data": ["put buyer produk by id", 200, 0, 0.0, 1681.479999999999, 1020, 2994, 1600.0, 2291.5000000000005, 2646.1, 2989.5300000000007, 2.817377584943934, 1.8571580760128472, 2.701078219206063], "isController": false}, {"data": ["POST buyer", 200, 0, 0.0, 2259.999999999999, 1200, 3833, 2137.5, 3106.5, 3437.2999999999993, 3688.2200000000007, 2.737101409607226, 1.7828580470781443, 11.08151857807582], "isController": false}, {"data": ["Get buyer order id-0", 200, 0, 0.0, 25.234999999999996, 14, 310, 24.0, 32.0, 34.0, 52.87000000000012, 2.8773666340565116, 1.1492606966104622, 0.9694252819819302], "isController": false}, {"data": ["Get buyer order id-1", 200, 0, 0.0, 729.7800000000002, 190, 1580, 740.5, 1163.3000000000002, 1271.6999999999998, 1441.97, 2.8339048374755578, 2.404944632584238, 0.9547823915322924], "isController": false}, {"data": ["Get buyer order id", 200, 0, 0.0, 755.1249999999999, 210, 1610, 762.5, 1186.4000000000003, 1300.85, 1470.8200000000002, 2.8327006968443715, 3.5353432525069404, 1.9087533992408363], "isController": false}, {"data": ["put buyer produk by id-1", 200, 0, 0.0, 1656.945, 990, 2973, 1578.5, 2262.4, 2615.2, 2960.5300000000007, 2.8185290097098323, 0.7376618892599952, 0.9440971194633521], "isController": false}, {"data": ["put buyer produk by id-0", 200, 0, 0.0, 24.46500000000001, 14, 42, 27.0, 30.900000000000006, 31.94999999999999, 36.960000000000036, 2.8709232889297196, 1.1410798619085898, 1.7907664378301562], "isController": false}, {"data": ["delete produk", 200, 0, 0.0, 1890.5950000000012, 101, 3916, 2067.5, 2639.7, 2796.1999999999994, 3761.4900000000007, 2.425447798299761, 2.643359123928255, 1.943437420414994], "isController": false}, {"data": ["POST buyer-0", 200, 0, 0.0, 32.20499999999998, 16, 67, 30.0, 48.0, 49.94999999999999, 62.960000000000036, 2.7816411682892905, 1.0892950278164115, 10.346401251738525], "isController": false}, {"data": ["Get seller produk id-0", 200, 0, 0.0, 25.915000000000003, 14, 42, 29.0, 33.0, 34.0, 36.0, 2.376792993214256, 0.9516456320486767, 0.8030960699727857], "isController": false}, {"data": ["POST buyer-1", 200, 0, 0.0, 2227.705000000002, 1170, 3802, 2106.0, 3077.4, 3416.099999999999, 3639.3200000000006, 2.7385630759540467, 0.7113845490271254, 0.9012653873012829], "isController": false}, {"data": ["Get seller produk id-1", 200, 0, 0.0, 1893.9799999999973, 270, 3351, 1866.5, 2924.6, 3155.599999999999, 3330.84, 2.369949046095509, 1.6594272129399217, 0.8007835644033653], "isController": false}, {"data": ["Get produk-0", 200, 0, 0.0, 25.549999999999997, 14, 45, 28.0, 31.0, 34.0, 40.98000000000002, 2.3447483498833486, 0.9250764974149149, 0.7785297255472057], "isController": false}, {"data": ["Get seller produk id", 200, 0, 0.0, 1919.9599999999994, 300, 3380, 1892.0, 2955.4, 3185.249999999999, 3359.8500000000004, 2.369162974721031, 2.6074674536236344, 1.6010359165106967], "isController": false}, {"data": ["Get produk-1", 200, 0, 0.0, 1770.975, 871, 3310, 1828.0, 2341.0, 2403.8, 2769.1600000000008, 2.3218017181332713, 3.655023798467611, 0.7709107267239378], "isController": false}, {"data": ["Get buyer order-1", 200, 0, 0.0, 1671.3149999999996, 930, 2181, 1709.5, 2097.0, 2129.95, 2165.88, 2.807411566535654, 0.7292690202133634, 0.9239235331274566], "isController": false}, {"data": ["Get buyer order-0", 200, 0, 0.0, 25.189999999999984, 14, 74, 27.5, 31.0, 33.0, 48.99000000000001, 2.8786919223904657, 1.1273002547642352, 0.947382009614831], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 5200, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
