/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 96.29629629629629, "KoPercent": 3.7037037037037037};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.2461111111111111, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.27, 500, 1500, "DELETE produk-1"], "isController": false}, {"data": [0.32, 500, 1500, "Get categories By Id-1"], "isController": false}, {"data": [0.51, 500, 1500, "Get categories By Id-0"], "isController": false}, {"data": [0.2775, 500, 1500, "Login User"], "isController": false}, {"data": [0.3975, 500, 1500, "DELETE produk-0"], "isController": false}, {"data": [0.41, 500, 1500, "GET produk"], "isController": false}, {"data": [0.0, 500, 1500, "PUT OFFERS"], "isController": false}, {"data": [0.015, 500, 1500, "GET produk by id "], "isController": false}, {"data": [0.3075, 500, 1500, "LIST OFFERS-0"], "isController": false}, {"data": [0.09, 500, 1500, "LIST OFFERS-1"], "isController": false}, {"data": [0.21, 500, 1500, "POST OFFERS"], "isController": false}, {"data": [0.5225, 500, 1500, "Get categories"], "isController": false}, {"data": [0.41, 500, 1500, "PUT produk by id -0"], "isController": false}, {"data": [0.005, 500, 1500, "PUT produk by id "], "isController": false}, {"data": [0.0, 500, 1500, "Regis User"], "isController": false}, {"data": [0.255, 500, 1500, "PUT produk by id -1"], "isController": false}, {"data": [0.0, 500, 1500, "LIST OFFERS"], "isController": false}, {"data": [0.005, 500, 1500, "DELETE produk"], "isController": false}, {"data": [0.0975, 500, 1500, "Get categories By Id"], "isController": false}, {"data": [0.43, 500, 1500, "GET PROFILE"], "isController": false}, {"data": [0.5125, 500, 1500, "GET produk by id -0"], "isController": false}, {"data": [0.3175, 500, 1500, "GET produk by id -1"], "isController": false}, {"data": [0.3875, 500, 1500, "POST produk"], "isController": false}, {"data": [0.13, 500, 1500, "PUT OFFERS-0"], "isController": false}, {"data": [0.025, 500, 1500, "PUT OFFERS-1"], "isController": false}, {"data": [0.4625, 500, 1500, "edit PROFILE"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 5400, 200, 3.7037037037037037, 1885.0462962962952, 38, 7370, 1633.0, 3689.0, 4399.0, 4968.98, 26.43831793546113, 313.01596699218845, 51.10665130245436], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["DELETE produk-1", 200, 0, 0.0, 1708.8099999999993, 330, 3738, 1460.0, 2898.0, 3086.8999999999996, 3560.5700000000015, 1.1316953928680555, 27.184771111070244, 0.8451134277072984], "isController": false}, {"data": ["Get categories By Id-1", 200, 0, 0.0, 1469.7750000000003, 639, 2919, 1253.5, 2423.7, 2628.5999999999995, 2759.9, 1.0723458100768337, 25.75424866761033, 0.7873468723694017], "isController": false}, {"data": ["Get categories By Id-0", 200, 0, 0.0, 966.0499999999998, 210, 2574, 770.0, 1917.2, 2030.85, 2553.4800000000005, 1.0760324531387866, 0.7481788150730626, 0.8152732214528591], "isController": false}, {"data": ["Login User", 400, 0, 0.0, 1769.1374999999994, 208, 7010, 1508.5, 3084.300000000001, 4692.899999999998, 6108.220000000001, 2.048687047688313, 4.224551745673429, 1.6571257336860488], "isController": false}, {"data": ["DELETE produk-0", 200, 0, 0.0, 1175.7149999999988, 217, 3176, 1021.0, 2114.9, 2357.1, 2837.8500000000004, 1.1203854125819284, 0.7790179821858719, 4.46942967130693], "isController": false}, {"data": ["GET produk", 200, 0, 0.0, 1158.0699999999993, 381, 3209, 1005.5, 2069.8, 2166.95, 2905.3000000000034, 1.0901737191821517, 8.073332579296512, 0.8568829310138071], "isController": false}, {"data": ["PUT OFFERS", 200, 0, 0.0, 4283.485000000001, 3077, 5503, 4375.5, 4889.1, 5054.549999999999, 5368.9400000000005, 1.8051356108127623, 45.58796827756216, 8.828505770792905], "isController": false}, {"data": ["GET produk by id ", 200, 0, 0.0, 2547.65, 1048, 4749, 2104.5, 4216.0, 4384.9, 4707.210000000001, 1.0910300960652, 26.933388436035635, 1.6562135186811628], "isController": false}, {"data": ["LIST OFFERS-0", 200, 0, 0.0, 1469.205, 451, 3304, 1199.0, 2637.7, 3079.2999999999997, 3275.7400000000002, 1.8478140359954176, 2.396113152047378, 1.4120258624672013], "isController": false}, {"data": ["LIST OFFERS-1", 200, 0, 0.0, 2260.6499999999987, 852, 4316, 2219.0, 3417.8, 3662.45, 4313.780000000001, 1.8669255470091852, 44.70632167243858, 1.3725731426424463], "isController": false}, {"data": ["POST OFFERS", 200, 0, 0.0, 1936.7449999999994, 630, 5714, 1654.5, 3176.0, 4568.849999999998, 5643.26, 1.7941886230499413, 4.923278111571619, 1.5279688775555973], "isController": false}, {"data": ["Get categories", 200, 0, 0.0, 955.455, 210, 3090, 837.0, 1917.5, 2178.0499999999997, 2657.000000000001, 1.0645205931508746, 1.112340854171324, 0.7971949383376447], "isController": false}, {"data": ["PUT produk by id -0", 200, 0, 0.0, 1199.1649999999997, 204, 3080, 1019.5, 2168.9, 2743.6499999999987, 3008.98, 1.1008669327095089, 0.7654465391495803, 4.201253311201321], "isController": false}, {"data": ["PUT produk by id ", 200, 0, 0.0, 2928.804999999999, 1485, 5093, 2251.0, 4675.3, 4887.549999999999, 5057.52, 1.0946967416351485, 27.044686119655825, 4.995489293523773], "isController": false}, {"data": ["Regis User", 200, 200, 100.0, 2200.4950000000003, 773, 7370, 1693.5, 3577.3000000000006, 4786.749999999998, 7289.440000000002, 1.029526829469176, 0.6263625144133755, 0.8573324348566899], "isController": false}, {"data": ["PUT produk by id -1", 200, 0, 0.0, 1729.38, 627, 3569, 1493.0, 2875.9, 3130.95, 3537.4300000000003, 1.1069293779056897, 26.577233835371928, 0.8269216466958158], "isController": false}, {"data": ["LIST OFFERS", 200, 0, 0.0, 3730.095, 1949, 5074, 3691.5, 4598.7, 4773.15, 5059.6, 1.8110364561638626, 45.716396501530326, 2.7154051005577995], "isController": false}, {"data": ["DELETE produk", 200, 0, 0.0, 2884.719999999998, 548, 5023, 2279.0, 4623.8, 4768.45, 4976.67, 1.1183117965119855, 27.640856176016683, 5.296276615820757], "isController": false}, {"data": ["Get categories By Id", 200, 0, 0.0, 2435.9549999999995, 1032, 4819, 1961.0, 4029.7000000000003, 4316.399999999999, 4657.92, 1.0700966832353302, 26.44428357695868, 1.5964713896275529], "isController": false}, {"data": ["GET PROFILE", 200, 0, 0.0, 1169.269999999999, 38, 3072, 1034.0, 2230.2000000000003, 2632.5499999999993, 3048.4200000000005, 1.1480792633923447, 1.8263934184203576, 0.8708136365984708], "isController": false}, {"data": ["GET produk by id -0", 200, 0, 0.0, 1009.4649999999996, 194, 3389, 876.5, 1959.5000000000002, 2140.95, 2918.6500000000005, 1.0984665407091698, 0.7637775165868448, 0.8476964985005931], "isController": false}, {"data": ["GET produk by id -1", 200, 0, 0.0, 1537.8700000000001, 647, 3618, 1340.0, 2446.0, 2917.5, 3553.740000000002, 1.0976105019372824, 26.332651357058186, 0.8191668690386029], "isController": false}, {"data": ["POST produk", 200, 0, 0.0, 1188.9399999999996, 331, 2594, 957.5, 2244.1, 2397.4999999999995, 2537.75, 1.0828663472210942, 2.080541568531904, 5.084988088470181], "isController": false}, {"data": ["PUT OFFERS-0", 200, 0, 0.0, 1956.8350000000007, 719, 4267, 2010.0, 2677.7000000000003, 2995.8499999999995, 3922.7400000000002, 1.8397063828612954, 2.4045178014588875, 7.626103967556778], "isController": false}, {"data": ["PUT OFFERS-1", 200, 0, 0.0, 2326.344999999999, 1041, 3679, 2330.0, 2987.1, 3347.4999999999995, 3596.59, 1.8388437350593947, 44.03586298373083, 1.3708364555367585], "isController": false}, {"data": ["edit PROFILE", 200, 0, 0.0, 1129.0250000000003, 50, 3680, 1020.5, 2082.4, 2607.8999999999996, 3643.800000000004, 1.1600524343700336, 1.8457691709540271, 5.222932170284096], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["401/Unauthorized", 200, 100.0, 3.7037037037037037], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 5400, 200, "401/Unauthorized", 200, "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Regis User", 200, 200, "401/Unauthorized", 200, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
