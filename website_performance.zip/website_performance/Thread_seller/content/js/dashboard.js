/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 94.73684210526316, "KoPercent": 5.2631578947368425};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.29368421052631577, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.225, 500, 1500, "DELETE produk-1"], "isController": false}, {"data": [0.335, 500, 1500, "Get categories By Id-1"], "isController": false}, {"data": [0.5, 500, 1500, "Get categories By Id-0"], "isController": false}, {"data": [0.4025, 500, 1500, "Login User"], "isController": false}, {"data": [0.3925, 500, 1500, "DELETE produk-0"], "isController": false}, {"data": [0.4, 500, 1500, "GET produk"], "isController": false}, {"data": [0.015, 500, 1500, "DELETE produk"], "isController": false}, {"data": [0.105, 500, 1500, "Get categories By Id"], "isController": false}, {"data": [0.025, 500, 1500, "GET produk by id "], "isController": false}, {"data": [0.4225, 500, 1500, "GET PROFILE"], "isController": false}, {"data": [0.465, 500, 1500, "GET produk by id -0"], "isController": false}, {"data": [0.51, 500, 1500, "Get categories"], "isController": false}, {"data": [0.3, 500, 1500, "GET produk by id -1"], "isController": false}, {"data": [0.4125, 500, 1500, "POST produk"], "isController": false}, {"data": [0.395, 500, 1500, "PUT produk by id -0"], "isController": false}, {"data": [0.0175, 500, 1500, "PUT produk by id "], "isController": false}, {"data": [0.0, 500, 1500, "Regis User"], "isController": false}, {"data": [0.2275, 500, 1500, "PUT produk by id -1"], "isController": false}, {"data": [0.43, 500, 1500, "edit PROFILE"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 3800, 200, 5.2631578947368425, 1617.0492105263136, 65, 6238, 1396.5, 2940.9, 3889.95, 4729.0, 18.77924991722304, 211.37390328253875, 37.301361364349575], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["DELETE produk-1", 200, 0, 0.0, 1710.6699999999992, 431, 3360, 1579.5, 2787.1, 2939.0, 3259.290000000001, 1.1371518893778643, 27.317259025077043, 0.8477111975346547], "isController": false}, {"data": ["Get categories By Id-1", 200, 0, 0.0, 1447.0650000000005, 469, 2938, 1238.0, 2443.2000000000003, 2572.5499999999997, 2857.130000000001, 1.0792259791277696, 25.91877121353565, 0.7928727579080284], "isController": false}, {"data": ["Get categories By Id-0", 200, 0, 0.0, 955.3899999999999, 153, 2697, 827.0, 1772.6000000000001, 1964.75, 2681.770000000004, 1.0812213476342878, 0.7517867182769656, 0.8196798165707984], "isController": false}, {"data": ["Login User", 200, 0, 0.0, 1509.015, 183, 6238, 977.5, 3710.6, 5136.3499999999985, 6236.200000000002, 1.039085189399253, 2.14203758760787, 0.8398933703767203], "isController": false}, {"data": ["DELETE produk-0", 200, 0, 0.0, 1203.2150000000006, 201, 2612, 1102.5, 2047.8000000000002, 2302.5999999999985, 2589.95, 1.1275355455580738, 0.7839895590208482, 4.496708653271544], "isController": false}, {"data": ["GET produk", 200, 0, 0.0, 1141.45, 300, 2611, 972.5, 1979.6, 2080.9, 2601.130000000002, 1.0967618107537496, 8.121456945244168, 0.8619219722519262], "isController": false}, {"data": ["DELETE produk", 200, 0, 0.0, 2914.0, 770, 4979, 2397.5, 4575.2, 4733.9, 4928.8200000000015, 1.1247961307013103, 27.802527320243517, 5.32428399696305], "isController": false}, {"data": ["Get categories By Id", 200, 0, 0.0, 2402.595, 916, 5088, 2002.0, 3723.1000000000004, 4297.499999999999, 4861.640000000002, 1.0750607409318627, 26.566241715313165, 1.6048221177621536], "isController": false}, {"data": ["GET produk by id ", 200, 0, 0.0, 2568.5799999999995, 1292, 4857, 2204.5, 4114.7, 4303.2, 4538.71, 1.097887664134206, 27.099491437848577, 1.6656799973101752], "isController": false}, {"data": ["GET PROFILE", 200, 0, 0.0, 1109.7600000000002, 68, 2605, 1024.5, 1840.9, 2073.2, 2587.4000000000005, 1.153469058192514, 1.8351253406338315, 0.8753523487513698], "isController": false}, {"data": ["GET produk by id -0", 200, 0, 0.0, 996.9250000000004, 288, 2953, 818.5, 1657.8000000000002, 2042.2499999999993, 2938.6000000000004, 1.1055465269255855, 0.7687003195029463, 0.8526851479497639], "isController": false}, {"data": ["Get categories", 200, 0, 0.0, 984.4749999999991, 162, 3061, 835.0, 1883.4, 2008.75, 2573.99, 1.0671447475135527, 1.115082890468263, 0.7996290671554189], "isController": false}, {"data": ["GET produk by id -1", 200, 0, 0.0, 1571.4699999999991, 695, 3576, 1387.5, 2579.0000000000005, 2926.4499999999994, 3388.91, 1.1040452216922805, 26.483823839924487, 0.8234948240979951], "isController": false}, {"data": ["POST produk", 200, 0, 0.0, 1159.4499999999996, 285, 2668, 949.0, 2162.5, 2378.6499999999996, 2522.94, 1.0873169909589593, 2.088317577430561, 5.104624104322629], "isController": false}, {"data": ["PUT produk by id -0", 200, 0, 0.0, 1192.7950000000005, 182, 2650, 1097.0, 2073.6, 2268.4999999999995, 2618.8500000000004, 1.1075668970405812, 0.7701051080985292, 4.224513241654484], "isController": false}, {"data": ["PUT produk by id ", 200, 0, 0.0, 2917.0249999999983, 1322, 4983, 2410.5, 4588.9, 4714.0, 4958.170000000001, 1.1012973282526817, 27.20801295332151, 5.021776003694852], "isController": false}, {"data": ["Regis User", 200, 200, 100.0, 2081.3299999999995, 685, 5953, 1822.0, 3280.6000000000004, 4237.499999999999, 5788.930000000005, 1.036317755750268, 0.6304941033519698, 0.8629571780549351], "isController": false}, {"data": ["PUT produk by id -1", 200, 0, 0.0, 1724.0499999999995, 537, 3220, 1544.5, 2674.7000000000003, 2964.649999999999, 3148.3600000000006, 1.1121800397048274, 26.70356222577811, 0.8292909643713124], "isController": false}, {"data": ["edit PROFILE", 200, 0, 0.0, 1134.6749999999995, 65, 3489, 911.5, 2070.8, 2417.9999999999995, 3419.530000000006, 1.167358326475103, 1.8577470367338482, 5.256971363605853], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["401/Unauthorized", 200, 100.0, 5.2631578947368425], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 3800, 200, "401/Unauthorized", 200, "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Regis User", 200, 200, "401/Unauthorized", 200, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
